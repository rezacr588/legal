# Docker Container Monitoring & Management

**Date Created**: 2025-10-18
**Status**: Active

This guide covers the web-based monitoring and management tools configured for the UK Legal Dashboard platform.

---

## Overview

The platform includes two lightweight monitoring tools that run as Docker containers:

1. **Portainer** - Full Docker management interface
2. **Dozzle** - Real-time log viewer

These tools eliminate the need for CLI commands during development and troubleshooting.

---

## Quick Access

| Service | URL | Purpose |
|---------|-----|---------|
| **Dozzle** | http://localhost:8080 | View container logs in real-time |
| **Portainer** | http://localhost:9000 | Manage containers (stop/restart/inspect) |
| Backend API | http://localhost:5000 | Flask API endpoints |
| Frontend UI | http://localhost:5173 | React application |

---

## Dozzle - Log Monitoring

### Access
Open http://localhost:8080 in your browser.

### Features
- **Real-time log streaming** for all containers
- **Multi-container view** - see backend and frontend logs side-by-side
- **Search and filter** - find specific log entries
- **Auto-refresh** - logs update automatically
- **No authentication required** (development only)

### Common Use Cases

**View Backend Logs**:
1. Open http://localhost:8080
2. Click on "backend" container
3. Logs stream in real-time

**View Frontend Logs**:
1. Click on "frontend" container
2. See Vite dev server output and React errors

**Search Logs**:
1. Use the search box at the top
2. Enter keywords (e.g., "error", "API", "POST /api/generate")
3. Matching lines highlighted

**Multi-container View**:
1. Click the grid icon to split view
2. Select multiple containers
3. See logs side-by-side

---

## Portainer - Container Management

### First Time Setup

1. Open http://localhost:9000
2. **Create admin account** (first visit only):
   - Username: `admin`
   - Password: Choose a secure password (min 12 characters)
3. Click "Get Started"
4. Select the local Docker environment

### Dashboard Overview

After login, you'll see:
- **Containers**: All running containers with status
- **Images**: Available Docker images
- **Volumes**: Persistent data volumes
- **Networks**: Container networks

### Managing Containers

**View Container Details**:
1. Click "Containers" in left menu
2. Click on any container name
3. See stats (CPU, memory, network)

**Stop a Container**:
1. Go to Containers list
2. Select checkbox next to container
3. Click "Stop" button
4. Confirm action

**Restart a Container**:
1. Go to Containers list
2. Select container
3. Click "Restart" button

**View Container Logs** (alternative to Dozzle):
1. Click on container name
2. Click "Logs" tab
3. Logs displayed with timestamps

**Inspect Container**:
1. Click container name
2. Click "Inspect" tab
3. View full container configuration (JSON)

**Execute Commands in Container**:
1. Click container name
2. Click "Console" tab
3. Choose shell (/bin/sh or /bin/bash)
4. Run commands interactively

---

## Common Workflows

### Troubleshooting Backend Issues

**Scenario**: Backend not responding

1. **Check Dozzle** (http://localhost:8080):
   - Click "backend" container
   - Look for error messages in logs

2. **Check Portainer** (http://localhost:9000):
   - Go to Containers
   - Check if backend container is running
   - View resource usage (CPU/memory)

3. **Restart Backend**:
   - In Portainer, select "backend"
   - Click "Restart"
   - Monitor logs in Dozzle

### Troubleshooting Frontend Issues

**Scenario**: Frontend not loading

1. **Check Dozzle**:
   - View "frontend" container logs
   - Look for Vite compilation errors

2. **Check Portainer**:
   - Verify frontend container is running
   - Check port mapping (5173)

3. **Restart Frontend**:
   - Select "frontend" in Portainer
   - Click "Restart"

### Monitoring Batch Generation

**Scenario**: Monitoring long-running batch generation

1. **Open Dozzle** to backend logs
2. **Enable auto-scroll** (scroll to bottom)
3. **Watch for**:
   - "Generated sample X/Y"
   - "Saved X samples to parquet"
   - Any error messages
4. **Search** for "ERROR" or "WARN" to find issues

### Clean Restart of All Services

**Using Portainer**:
1. Go to Containers
2. Select all containers (backend, frontend, dozzle, portainer)
3. Click "Stop"
4. Wait for all to stop
5. Select all again
6. Click "Start"

**Using CLI** (alternative):
```bash
docker-compose restart
```

---

## Resource Usage

| Service | Memory Usage | CPU Usage |
|---------|--------------|-----------|
| Portainer | ~50MB | Minimal |
| Dozzle | ~10MB | Minimal |
| Backend | ~200-300MB | Variable |
| Frontend | ~100-150MB | Minimal |

Total monitoring overhead: **~60MB** (negligible impact)

---

## Configuration Details

### Dozzle Settings

Configured in `docker-compose.yml`:
```yaml
environment:
  - DOZZLE_LEVEL=info          # Log level (debug|info|warn|error)
  - DOZZLE_TAILSIZE=300        # Number of initial log lines
  - DOZZLE_FILTER=name=backend,name=frontend  # Only show these containers
```

**To show all containers** (including monitoring):
1. Edit `docker-compose.yml`
2. Remove or comment out `DOZZLE_FILTER` line
3. Restart: `docker-compose restart dozzle`

### Portainer Persistence

- Data stored in Docker volume: `portainer_data`
- Survives container restarts
- Includes user accounts, settings, templates

**To reset Portainer**:
```bash
docker-compose down
docker volume rm data_portainer_data
docker-compose up -d
# Re-create admin account on first visit
```

---

## Security Considerations

### Development Environment

Current setup is optimized for **local development**:
- Portainer requires authentication (admin account)
- Dozzle has **no authentication** (localhost only)
- Services bind to `localhost` (not accessible from network)

### Production Environment

If deploying to production:

1. **Enable Dozzle Authentication**:
   - Add environment variable: `DOZZLE_USERNAME=admin`
   - Add environment variable: `DOZZLE_PASSWORD=secure_password`

2. **Use Reverse Proxy** with HTTPS:
   - Add nginx/traefik in front
   - Configure SSL certificates
   - Add IP whitelisting

3. **Restrict Port Access**:
   - Change port bindings to `127.0.0.1:8080:8080`
   - Use VPN or SSH tunnel for remote access

---

## Troubleshooting

### Portainer Not Accessible

**Problem**: http://localhost:9000 not loading

**Solution**:
```bash
# Check if container is running
docker ps | grep portainer

# Check logs
docker logs portainer

# Restart container
docker-compose restart portainer

# Verify port not in use
lsof -ti:9000
```

### Dozzle Not Showing Logs

**Problem**: Containers appear but no logs

**Solution**:
1. Check `DOZZLE_FILTER` environment variable
2. Verify Docker socket mounted: `/var/run/docker.sock`
3. Check container permissions: `docker logs dozzle`

### Port Conflicts

**Problem**: Port 8080 or 9000 already in use

**Solution**:
```bash
# Find process using port
lsof -ti:8080
lsof -ti:9000

# Kill process
lsof -ti:8080 | xargs kill -9

# Or change port in docker-compose.yml
# Change "8080:8080" to "8081:8080" for Dozzle
# Change "9000:9000" to "9001:9000" for Portainer
```

---

## Advanced Features

### Portainer Templates

Create custom templates for common tasks:
1. Go to "App Templates" in Portainer
2. Create template for restarting all services
3. One-click execution

### Dozzle Log Export

Export logs for analysis:
1. View container logs in Dozzle
2. Select time range
3. Copy logs to clipboard
4. Paste into log analysis tool

### Container Resource Limits

Set limits in Portainer:
1. Click container name
2. Click "Duplicate/Edit"
3. Go to "Resources" tab
4. Set memory/CPU limits
5. Click "Deploy"

---

## Integration with Development Workflow

### Typical Development Session

1. **Start services**:
   ```bash
   docker-compose up -d
   ```

2. **Open monitoring**:
   - Dozzle: http://localhost:8080 (keep open in browser tab)
   - Portainer: http://localhost:9000 (for management)

3. **Develop code**:
   - Edit files in `backend/` or `frontend/`
   - Changes auto-reload (hot-reload enabled)
   - Watch logs in Dozzle for errors

4. **Monitor batch generation**:
   - Start batch via React UI or API
   - Watch backend logs in Dozzle
   - See progress in real-time

5. **Restart if needed**:
   - Use Portainer to restart individual containers
   - No need to stop entire stack

6. **Cleanup**:
   ```bash
   docker-compose down
   ```

---

## Keyboard Shortcuts

### Dozzle
- `Ctrl+F` - Search logs
- `Esc` - Clear search
- Scroll to bottom - Enable auto-scroll
- Scroll up - Disable auto-scroll

### Portainer
- Standard browser shortcuts apply
- No special keyboard shortcuts

---

## Additional Resources

- **Portainer Documentation**: https://docs.portainer.io/
- **Dozzle Documentation**: https://dozzle.dev/
- **Docker Compose Documentation**: https://docs.docker.com/compose/

---

## Summary

With Portainer and Dozzle configured, you can:

✅ View logs in real-time without CLI
✅ Stop/restart containers via web UI
✅ Monitor resource usage (CPU/memory)
✅ Search and filter logs easily
✅ Execute commands in containers (Portainer console)
✅ Inspect container configurations
✅ Manage volumes and networks

No CLI commands needed for daily development tasks.

---

**Quick Reference Card**:
```
📊 View Logs     → http://localhost:8080 (Dozzle)
🛠️  Manage        → http://localhost:9000 (Portainer)
🔧 Backend API   → http://localhost:5000
💻 Frontend UI   → http://localhost:5173
```
