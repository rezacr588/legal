# Docker Setup Guide

This guide explains how to run the Legal AI Training Platform using Docker Compose.

## Prerequisites

- Docker installed ([Download Docker](https://www.docker.com/get-started))
- Docker Compose installed (included with Docker Desktop)
- API keys for LLM providers (Groq, Cerebras, etc.)

## Quick Start

### 1. Set Up Environment Variables

Copy the example environment file and add your API keys:

```bash
cp .env.example .env
```

Edit `.env` and add your actual API keys:

```env
GROQ_API_KEY=your_actual_groq_key
CEREBRAS_API_KEY=your_actual_cerebras_key
OLLAMA_API_KEY=your_actual_ollama_key
HUGGINGFACE_TOKEN=your_actual_hf_token
```

### 2. Start All Services

```bash
docker-compose up
```

Or run in detached mode (background):

```bash
docker-compose up -d
```

### 3. Access the Application

- **Frontend**: http://localhost:5173
- **Backend API**: http://localhost:5000
- **API Health Check**: http://localhost:5000/api/health

### 4. Access Monitoring Tools

The platform includes web-based monitoring and management tools:

- **Dozzle (Logs)**: http://localhost:8080 - Real-time log viewer for all containers
- **Portainer (Management)**: http://localhost:9000 - Container management UI

**First Time Portainer Setup**:
1. Open http://localhost:9000
2. Create admin account (username: `admin`, password: choose secure password)
3. Click "Get Started" and select local Docker environment

**Common Monitoring Tasks**:
- **View logs**: Open Dozzle and click on backend or frontend container
- **Restart container**: Open Portainer → Containers → Select container → Click "Restart"
- **Monitor resources**: Portainer shows CPU and memory usage for each container

For detailed monitoring documentation, see [DOCKER_MONITORING.md](DOCKER_MONITORING.md).

### 5. Stop All Services

```bash
docker-compose down
```

## Service Details

### Backend Service

- **Port**: 5000
- **Technology**: Flask + Python 3.11
- **Data**: Persistent volume mounted at `./backend/data`
- **Features**:
  - Multi-provider AI (Groq, Cerebras, Ollama)
  - Batch generation support
  - HuggingFace integration
  - RESTful API

### Frontend Service

- **Port**: 5173
- **Technology**: React + Vite
- **Features**:
  - Real-time dashboard
  - Generation monitoring
  - Dataset management
  - Material UI components

## Common Commands

### View Logs

**Recommended: Use Dozzle Web UI**

Open http://localhost:8080 for real-time log viewing with search and filtering.

**Alternative: CLI Commands**

```bash
# All services
docker-compose logs -f

# Backend only
docker-compose logs -f backend

# Frontend only
docker-compose logs -f frontend

# Monitoring services
docker-compose logs -f portainer dozzle
```

### Rebuild Services

After code changes:

```bash
docker-compose up --build
```

### Check Service Status

```bash
docker-compose ps
```

### Access Shell

```bash
# Backend shell
docker-compose exec backend /bin/bash

# Frontend shell
docker-compose exec frontend /bin/sh
```

## Troubleshooting

### Port Already in Use

If you see "port already in use" errors:

```bash
# Stop services using those ports
lsof -ti:5000 | xargs kill -9  # Backend
lsof -ti:5173 | xargs kill -9  # Frontend

# Or change ports in docker-compose.yml
```

### Environment Variables Not Loading

Make sure you:
1. Created `.env` file (not just `.env.example`)
2. Added actual API keys (not placeholder text)
3. Restarted services after editing `.env`

```bash
docker-compose down
docker-compose up
```

### Data Persistence

The parquet dataset and database files are stored in `./backend/data/` and persist across container restarts.

### Fresh Start

To completely reset:

```bash
# Stop and remove containers
docker-compose down

# Remove volumes (WARNING: deletes all data)
docker-compose down -v

# Rebuild and start fresh
docker-compose up --build
```

## Development Workflow

### Live Reload

Both services support live reload:

- **Backend**: Flask debug mode enabled
- **Frontend**: Vite HMR (Hot Module Replacement)

Changes to source code will automatically reload the services.

### Volumes

Mounted volumes allow you to edit code locally:

- `./backend/data` → Container backend data
- `./legal-dashboard` → Container legal-dashboard (for compatibility)
- `./frontend/src` → Container frontend source

## Production Deployment

For production, you should:

1. **Use production builds**:
   ```yaml
   # In docker-compose.yml, change frontend command to:
   command: npm run build && npm run preview
   ```

2. **Disable debug mode**:
   ```python
   # In backend/app.py, set debug=False
   app.run(debug=False)
   ```

3. **Use environment-specific .env files**
4. **Set up reverse proxy (nginx)**
5. **Enable HTTPS**

## Architecture

```
┌─────────────────────┐     ┌─────────────────────┐
│   Frontend (5173)   │     │  Dozzle (8080)      │  ← Log Viewer
│   Docker Container  │     │  Docker Container   │
└──────────┬──────────┘     └─────────────────────┘
           │ HTTP                      │
           ▼                           │ Monitors
┌─────────────────────┐     ┌─────────▼───────────┐
│   Backend (5000)    │     │ Portainer (9000)    │  ← Management UI
│   Docker Container  │     │ Docker Container    │
└──────────┬──────────┘     └─────────────────────┘
           │                           │
           ▼                           │
┌─────────────────────┐                │
│   Persistent Volume │  ← train.parquet + batches.db
│   ./backend/data    │                │
└─────────────────────┘                │
           ▲                           │
           └───────────────────────────┘ Manages
```

## Network

Services communicate via the `legal-dashboard-network` bridge network:

- Frontend can reach backend at `http://backend:5000`
- Vite proxy configured for `/api` routes
- External access via published ports

## Next Steps

- See [DOCKER_MONITORING.md](DOCKER_MONITORING.md) for detailed monitoring guide
- See [CLAUDE.md](CLAUDE.md) for full platform documentation
- See [API_USAGE.md](API_USAGE.md) for API reference
- See [README.md](README.md) for general overview

## Support

For issues:
1. Check logs: `docker-compose logs -f`
2. Verify environment variables in `.env`
3. Ensure Docker has sufficient resources (4GB+ RAM recommended)
4. Check the GitHub issues page
