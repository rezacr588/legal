"""
Database models package.
Exports db instance and all models.
"""
from backend.models.batch import db, BatchHistory

__all__ = ['db', 'BatchHistory']
