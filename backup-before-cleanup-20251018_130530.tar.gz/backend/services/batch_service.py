"""
Batch Generation Service - Handles background batch generation logic.
Extracted from api_server.py for better separation of concerns.
"""
import time
import threading
from datetime import datetime
from typing import Dict, List, Optional
import polars as pl

from backend.config import (
    MAX_BATCH_TIMEOUT,
    MAX_MODEL_SWITCHES,
    MAX_SAMPLE_RETRIES,
    SAMPLE_TYPE_CYCLE,
    PARQUET_PATH,
    TOPICS
)
from backend.models import db, BatchHistory
from backend.services.generation_service import GenerationService
from backend.services.llm_service import LLMProviderFactory
from backend.utils.circuit_breaker import CircuitBreaker


class BatchService:
    """
    Service class for managing batch generation operations.
    Handles background workers, progress tracking, and database persistence.
    """

    def __init__(self, parquet_lock: threading.Lock):
        """
        Initialize batch service.

        Args:
            parquet_lock: Thread lock for safe parquet file writes
        """
        self.parquet_lock = parquet_lock
        self.generation_service = GenerationService()
        self.active_batches: Dict = {}  # In-memory batch state
        self.batch_lock = threading.Lock()

    def create_batch_state(self, batch_id: str, provider: str, model: str, total: int = 0) -> Dict:
        """Create initial batch state object."""
        return {
            'running': True,
            'progress': 0,
            'total': total,
            'current_sample': None,
            'current_provider': provider,
            'current_model': model,
            'errors': [],
            'batch_id': batch_id,
            'started_at': datetime.now().isoformat(),
            'completed_at': None,
            'samples_generated': 0,
            'total_tokens': 0,
            'model_switches': [],
            'provider_switches': [],
            'failed_models_by_provider': {provider: []},
            'consecutive_failures': 0,
            'skipped_topics': [],
            'circuit_breaker_summary': {}
        }

    def start_batch(self, batch_id: str, target_count: int, provider: str, model: str,
                    topic_filter: Optional[str] = None, difficulty_filter: Optional[str] = None,
                    reasoning_instruction: Optional[str] = None, sample_type_filter: str = 'case_analysis'):
        """
        Start a new batch generation job in background thread.

        Args:
            batch_id: Unique batch identifier
            target_count: Target total sample count
            provider: LLM provider name
            model: Model name
            topic_filter: Optional topic filter
            difficulty_filter: Optional difficulty filter
            reasoning_instruction: Optional custom reasoning requirements
            sample_type_filter: Sample type filter (or 'balance')
        """
        # Calculate samples needed
        df_existing = pl.read_parquet(PARQUET_PATH)
        current_count = len(df_existing)
        samples_needed = target_count - current_count

        if samples_needed <= 0:
            return {'error': f'Target already met: {current_count} samples exist'}

        # Create batch state
        with self.batch_lock:
            batch_state = self.create_batch_state(batch_id, provider, model, samples_needed)
            batch_state.update({
                'topic_filter': topic_filter,
                'difficulty_filter': difficulty_filter,
                'reasoning_instruction': reasoning_instruction,
                'sample_type_filter': sample_type_filter
            })
            self.active_batches[batch_id] = batch_state

        # Save to database
        self._save_batch_to_db(batch_state)

        # Start background worker thread
        thread = threading.Thread(
            target=self._batch_worker,
            args=(batch_id, target_count, provider, model)
        )
        thread.daemon = True
        thread.start()

        return {'batch_id': batch_id, 'samples_needed': samples_needed}

    def stop_batch(self, batch_id: Optional[str] = None):
        """
        Stop batch generation(s).

        Args:
            batch_id: Specific batch to stop, or None to stop all

        Returns:
            Dict with stop status
        """
        stopped_batches = []

        with self.batch_lock:
            if batch_id:
                # Stop specific batch
                if batch_id in self.active_batches:
                    batch_state = self.active_batches[batch_id]
                    if batch_state['running']:
                        batch_state['running'] = False
                        batch_state['completed_at'] = datetime.now().isoformat()
                        stopped_batches.append(batch_id)
                else:
                    return {'error': f'Batch {batch_id} not found'}
            else:
                # Stop all running batches
                for bid, batch_state in self.active_batches.items():
                    if batch_state.get('running', False):
                        batch_state['running'] = False
                        batch_state['completed_at'] = datetime.now().isoformat()
                        stopped_batches.append(bid)

        # Save to database
        for bid in stopped_batches:
            self._save_batch_to_db(self.active_batches[bid])

        return {'stopped_batches': stopped_batches, 'count': len(stopped_batches)}

    def get_batch_status(self, batch_id: Optional[str] = None):
        """Get status of specific batch or all batches."""
        with self.batch_lock:
            if batch_id:
                return self.active_batches.get(batch_id)
            else:
                return {
                    'batches': self.active_batches,
                    'count': len(self.active_batches)
                }

    def _batch_worker(self, batch_id: str, target_count: int, provider: str, model: str):
        """
        Background worker for batch generation.
        This is the main batch generation loop extracted from api_server.py.

        NOTE: This is a simplified version. Full implementation should include:
        - Complete error handling and model switching logic
        - Provider failover
        - Rate limiting with proper tracking
        - All the logic from api_server.py lines 376-759
        """
        # Import here to avoid circular imports
        from backend.routes.batches import broadcast_sse_update

        with self.batch_lock:
            if batch_id not in self.active_batches:
                print(f"❌ Batch {batch_id} not found in active_batches")
                return
            batch_state = self.active_batches[batch_id]

        # Get rate limits
        rate_limits = LLMProviderFactory.get_rate_limits(provider)
        requests_per_minute = rate_limits['requests_per_minute']
        request_delay = 60 / requests_per_minute

        # Initialize circuit breaker
        circuit_breaker = CircuitBreaker()

        # Load existing dataset
        df_existing = pl.read_parquet(PARQUET_PATH)
        current_count = len(df_existing)
        samples_needed = target_count - current_count

        # Get filters
        topic_filter = batch_state.get('topic_filter')
        difficulty_filter = batch_state.get('difficulty_filter')
        reasoning_instruction = batch_state.get('reasoning_instruction')
        sample_type_filter = batch_state.get('sample_type_filter', 'case_analysis')

        # Prepare topic cycle
        if topic_filter:
            filtered_topics = [t for t in TOPICS if f"{t[0]} - {t[1]}" == topic_filter]
            if not filtered_topics:
                filtered_topics = TOPICS
        else:
            filtered_topics = TOPICS

        topic_cycle = filtered_topics * ((samples_needed // len(filtered_topics)) + 10)

        generated_samples = []
        minute_start = time.time()
        minute_requests = 0
        minute_tokens = 0
        batch_start_time = time.time()
        iteration = 0
        max_iterations = samples_needed * 3

        # Main generation loop
        while batch_state['samples_generated'] < samples_needed and iteration < max_iterations:
            # Check for manual stop
            if not batch_state['running']:
                break

            # Check timeout
            elapsed_time = time.time() - batch_start_time
            if elapsed_time > MAX_BATCH_TIMEOUT:
                batch_state['errors'].append({
                    'error': f"Batch timed out after {int(elapsed_time/60)} minutes",
                    'timeout': True
                })
                batch_state['running'] = False
                break

            # Get current topic
            topic_index = iteration % len(topic_cycle)
            practice_area, topic, original_difficulty = topic_cycle[topic_index]
            topic_key = f"{practice_area} - {topic}"
            difficulty = difficulty_filter if difficulty_filter else original_difficulty

            # Circuit breaker check
            if circuit_breaker.is_open(topic_key):
                if topic_key not in batch_state['skipped_topics']:
                    batch_state['skipped_topics'].append(topic_key)
                iteration += 1
                continue

            # Determine sample type
            if sample_type_filter == 'balance':
                sample_type_index = iteration % len(SAMPLE_TYPE_CYCLE)
                current_sample_type = SAMPLE_TYPE_CYCLE[sample_type_index]
            else:
                current_sample_type = sample_type_filter

            # Rate limiting
            elapsed_minute = time.time() - minute_start
            if elapsed_minute < 60 and minute_requests >= requests_per_minute:
                wait_time = 60 - elapsed_minute
                time.sleep(wait_time)
                minute_start = time.time()
                minute_tokens = 0
                minute_requests = 0
            elif elapsed_minute >= 60:
                minute_start = time.time()
                minute_tokens = 0
                minute_requests = 0

            batch_state['current_sample'] = topic_key

            # Generate sample with retries
            sample_success = False
            sample_retries = 0

            while not sample_success and sample_retries < MAX_SAMPLE_RETRIES:
                sample, tokens_used, elapsed, error = self.generation_service.generate_single_sample(
                    practice_area, topic, difficulty,
                    current_count + batch_state['samples_generated'] + 1,
                    provider, model, reasoning_instruction, batch_id, current_sample_type
                )

                if sample:
                    generated_samples.append(sample)
                    batch_state['samples_generated'] += 1
                    batch_state['total_tokens'] += tokens_used
                    batch_state['consecutive_failures'] = 0
                    minute_tokens += tokens_used
                    minute_requests += 1
                    sample_success = True

                    circuit_breaker.record_success(topic_key)

                    # Auto-save to parquet every sample
                    with self.parquet_lock:
                        df_fresh = pl.read_parquet(PARQUET_PATH)
                        existing_columns = df_fresh.columns
                        filtered_samples = [{k: v for k, v in s.items() if k in existing_columns}
                                          for s in generated_samples]
                        df_new = pl.DataFrame(filtered_samples)
                        df_combined = pl.concat([df_fresh, df_new])
                        df_combined.write_parquet(PARQUET_PATH, compression="zstd",
                                                statistics=True, use_pyarrow=False)

                    generated_samples = []
                    batch_state['circuit_breaker_summary'] = circuit_breaker.get_summary()
                    broadcast_sse_update(batch_id)

                else:
                    # Handle failure
                    sample_retries += 1
                    batch_state['consecutive_failures'] += 1
                    circuit_breaker.record_failure(topic_key, error)

                    # (Model switching logic would go here - see original api_server.py)

                    if sample_retries < MAX_SAMPLE_RETRIES:
                        time.sleep(2)

            iteration += 1
            batch_state['progress'] = iteration
            broadcast_sse_update(batch_id)

            if batch_state['samples_generated'] % 10 == 0:
                self._save_batch_to_db(batch_state)

            time.sleep(request_delay)

        # Final save
        if generated_samples:
            with self.parquet_lock:
                df_fresh = pl.read_parquet(PARQUET_PATH)
                existing_columns = df_fresh.columns
                filtered_samples = [{k: v for k, v in s.items() if k in existing_columns}
                                  for s in generated_samples]
                df_new = pl.DataFrame(filtered_samples)
                df_combined = pl.concat([df_fresh, df_new])
                df_combined.write_parquet(PARQUET_PATH, compression="zstd",
                                        statistics=True, use_pyarrow=False)

        batch_state['completed_at'] = datetime.now().isoformat()
        batch_state['running'] = False
        batch_state['circuit_breaker_summary'] = circuit_breaker.get_summary()

        self._save_batch_to_db(batch_state)
        broadcast_sse_update(batch_id)

    def _save_batch_to_db(self, batch_state: Dict):
        """Save batch state to database."""
        import json
        from flask import current_app

        try:
            batch_id = batch_state.get('batch_id')
            if not batch_id:
                return

            with current_app.app_context():
                batch = BatchHistory.query.filter_by(batch_id=batch_id).first()

                if batch:
                    # Update existing
                    batch.completed_at = batch_state.get('completed_at')
                    batch.samples_generated = batch_state.get('samples_generated', 0)
                    batch.total_tokens = batch_state.get('total_tokens', 0)
                    batch.status = 'running' if batch_state.get('running') else 'completed'
                    batch.errors = json.dumps(batch_state.get('errors', []))
                    batch.model_switches = json.dumps(batch_state.get('model_switches', []))
                    batch.model = batch_state.get('current_model', batch.model)
                else:
                    # Create new
                    batch = BatchHistory(
                        batch_id=batch_id,
                        started_at=batch_state['started_at'],
                        model=batch_state.get('current_model'),
                        topic_filter=batch_state.get('topic_filter'),
                        difficulty_filter=batch_state.get('difficulty_filter'),
                        reasoning_instruction=batch_state.get('reasoning_instruction'),
                        target_count=batch_state.get('total', 0),
                        samples_generated=batch_state.get('samples_generated', 0),
                        total_tokens=batch_state.get('total_tokens', 0),
                        status='running' if batch_state.get('running') else 'stopped',
                        errors=json.dumps(batch_state.get('errors', [])),
                        model_switches=json.dumps(batch_state.get('model_switches', []))
                    )
                    db.session.add(batch)

                db.session.commit()
        except Exception as e:
            print(f"Error saving batch to database: {str(e)}")
            db.session.rollback()
