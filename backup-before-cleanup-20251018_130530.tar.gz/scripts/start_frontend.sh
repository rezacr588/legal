#!/bin/bash

echo "🚀 Starting React Frontend..."

cd "$(dirname "$0")/../frontend"
npm run dev
