#!/bin/bash

echo "🚀 Starting Flask Backend..."

cd "$(dirname "$0")/../backend"
python3 app.py
